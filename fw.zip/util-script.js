var mesaj = 'salutare';
console.log('mesajul este: ', mesaj);